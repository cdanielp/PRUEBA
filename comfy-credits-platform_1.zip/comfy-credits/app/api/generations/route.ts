import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "No autorizado" }, { status: 401 });

  const userId = (session.user as any).id;
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  // Polling de una generación específica
  if (id) {
    const gen = await db.generation.findFirst({
      where: { id, userId },
      select: {
        id: true, runId: true, workflowName: true, status: true,
        creditsCost: true, outputs: true, errorMsg: true, createdAt: true,
      },
    });
    if (!gen) return NextResponse.json({ error: "No encontrada" }, { status: 404 });
    return NextResponse.json({ generation: gen });
  }

  // Listado
  const limit = Math.min(parseInt(searchParams.get("limit") || "20"), 50);
  const generations = await db.generation.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: limit,
    select: {
      id: true, workflowName: true, status: true,
      creditsCost: true, outputs: true, errorMsg: true, createdAt: true,
    },
  });

  return NextResponse.json({ generations });
}
