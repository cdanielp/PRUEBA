// ============================================
// SISTEMA DE CRÉDITOS - Transacciones Atómicas
// ============================================
// Doc referencia: Sección 2.1 Deducción Atómica
// Todas las operaciones usan $transaction para evitar race conditions.

import { db } from "./db";
import { TransactionType } from "@prisma/client";

const MAX_CONCURRENT_RUNS = 2;

/**
 * Verificar si el usuario puede generar:
 * - Tiene suficientes créditos
 * - No excede el límite de runs concurrentes
 */
export async function canGenerate(userId: string, cost: number) {
  const [user, activeRuns] = await Promise.all([
    db.user.findUnique({ where: { id: userId }, select: { creditsBalance: true } }),
    db.generation.count({
      where: {
        userId,
        status: { in: ["QUEUED", "PROCESSING"] },
      },
    }),
  ]);

  if (!user) return { ok: false, reason: "USER_NOT_FOUND" } as const;
  if (user.creditsBalance < cost) return { ok: false, reason: "INSUFFICIENT_CREDITS", balance: user.creditsBalance } as const;
  if (activeRuns >= MAX_CONCURRENT_RUNS) return { ok: false, reason: "MAX_CONCURRENT", active: activeRuns } as const;

  return { ok: true, balance: user.creditsBalance } as const;
}

/**
 * Deducción optimista + registro en ledger.
 * Se ejecuta ANTES de llamar a ComfyDeploy.
 * Si ComfyDeploy falla, se llama refundCredits().
 */
export async function deductCredits(
  userId: string,
  amount: number,
  generationId: string,
  description: string
) {
  return await db.$transaction(async (tx) => {
    // UPDATE ... WHERE credits >= cost (atómico, previene race condition)
    const updated = await tx.user.updateMany({
      where: { id: userId, creditsBalance: { gte: amount } },
      data: { creditsBalance: { decrement: amount } },
    });

    if (updated.count === 0) {
      throw new Error("INSUFFICIENT_CREDITS");
    }

    // Leer saldo resultante
    const user = await tx.user.findUnique({
      where: { id: userId },
      select: { creditsBalance: true },
    });

    // Registrar en ledger
    await tx.creditTransaction.create({
      data: {
        userId,
        type: TransactionType.GENERATION,
        amount: -amount,
        generationId,
        description,
        balanceAfter: user!.creditsBalance,
      },
    });

    return { newBalance: user!.creditsBalance };
  });
}

/**
 * Reembolso automático por generación fallida.
 * Se llama desde el webhook o desde el catch del generate.
 */
export async function refundCredits(
  userId: string,
  amount: number,
  generationId: string
) {
  return await db.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: userId },
      data: { creditsBalance: { increment: amount } },
    });

    const user = await tx.user.findUnique({
      where: { id: userId },
      select: { creditsBalance: true },
    });

    await tx.creditTransaction.create({
      data: {
        userId,
        type: TransactionType.REFUND,
        amount: amount,
        generationId,
        description: `Reembolso automático: generación fallida`,
        balanceAfter: user!.creditsBalance,
      },
    });

    return { newBalance: user!.creditsBalance };
  });
}

/**
 * Ajuste manual de créditos por admin.
 */
export async function adminAdjustCredits(
  userId: string,
  amount: number,
  adminDescription: string
) {
  return await db.$transaction(async (tx) => {
    if (amount > 0) {
      await tx.user.update({
        where: { id: userId },
        data: { creditsBalance: { increment: amount } },
      });
    } else {
      const updated = await tx.user.updateMany({
        where: { id: userId, creditsBalance: { gte: Math.abs(amount) } },
        data: { creditsBalance: { increment: amount } },
      });
      if (updated.count === 0) throw new Error("INSUFFICIENT_CREDITS");
    }

    const user = await tx.user.findUnique({
      where: { id: userId },
      select: { creditsBalance: true },
    });

    await tx.creditTransaction.create({
      data: {
        userId,
        type: TransactionType.ADMIN_ADJUST,
        amount,
        description: adminDescription,
        balanceAfter: user!.creditsBalance,
      },
    });

    return { newBalance: user!.creditsBalance };
  });
}

/**
 * Agregar créditos de bienvenida al registrarse.
 */
export async function addWelcomeCredits(userId: string) {
  const WELCOME_AMOUNT = 5;
  return await db.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: userId },
      data: { creditsBalance: { increment: WELCOME_AMOUNT } },
    });

    const user = await tx.user.findUnique({
      where: { id: userId },
      select: { creditsBalance: true },
    });

    await tx.creditTransaction.create({
      data: {
        userId,
        type: TransactionType.BONUS,
        amount: WELCOME_AMOUNT,
        description: "Créditos de bienvenida",
        balanceAfter: user!.creditsBalance,
      },
    });

    return { balance: user!.creditsBalance };
  });
}
