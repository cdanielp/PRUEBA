// ============================================
// POST /api/generate
// ============================================
// Flujo: Auth → Validar → Verificar créditos/concurrencia
//        → Deducir créditos → Encolar en ComfyDeploy
//        → Si falla, reembolsar

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { canGenerate, deductCredits, refundCredits } from "@/lib/credits";
import { queueComfyRun } from "@/lib/comfy-deploy";
import { z } from "zod";

const generateSchema = z.object({
  workflowId: z.string().min(1),
  inputs: z.record(z.any()).default({}),
});

export async function POST(req: NextRequest) {
  try {
    // 1. AUTH
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 });
    }
    const userId = (session.user as any).id;

    // 2. VALIDAR INPUT
    const body = await req.json();
    const parsed = generateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Datos inválidos" }, { status: 400 });
    }

    const { workflowId, inputs } = parsed.data;

    // 3. BUSCAR WORKFLOW
    const workflow = await db.workflow.findUnique({ where: { id: workflowId } });
    if (!workflow || !workflow.active) {
      return NextResponse.json({ error: "Workflow no disponible" }, { status: 404 });
    }

    // 4. SANITIZAR INPUTS (doc sección 4.1)
    const sanitizedInputs: Record<string, any> = {};
    const schema = workflow.inputSchema as any;
    if (schema?.fields) {
      for (const field of schema.fields) {
        let value = inputs[field.name];
        if (field.required && (value === undefined || value === "")) {
          return NextResponse.json(
            { error: `Campo requerido: ${field.label}` },
            { status: 400 }
          );
        }
        if (value !== undefined) {
          if (field.type === "textarea" || field.type === "text") {
            // Truncar a maxLength (default 1000)
            value = String(value).slice(0, field.maxLength || 1000);
          }
          if (field.type === "number") {
            value = Number(value);
            if (isNaN(value)) continue;
          }
          sanitizedInputs[field.name] = value;
        }
      }
    }

    // 5. VERIFICAR CRÉDITOS + CONCURRENCIA
    const check = await canGenerate(userId, workflow.creditsCost);
    if (!check.ok) {
      const messages: Record<string, string> = {
        INSUFFICIENT_CREDITS: "Créditos insuficientes",
        MAX_CONCURRENT: "Tienes el máximo de generaciones activas (2). Espera a que terminen.",
        USER_NOT_FOUND: "Usuario no encontrado",
      };
      const statusCodes: Record<string, number> = {
        INSUFFICIENT_CREDITS: 402,
        MAX_CONCURRENT: 429,
        USER_NOT_FOUND: 404,
      };
      return NextResponse.json(
        { error: messages[check.reason], code: check.reason },
        { status: statusCodes[check.reason] || 400 }
      );
    }

    // 6. CREAR REGISTRO
    const generation = await db.generation.create({
      data: {
        userId,
        workflowId: workflow.id,
        workflowName: workflow.name,
        creditsCost: workflow.creditsCost,
        inputs: sanitizedInputs,
        status: "QUEUED",
      },
    });

    // 7. DEDUCCIÓN OPTIMISTA (doc sección 2.2)
    let newBalance: number;
    try {
      const result = await deductCredits(
        userId,
        workflow.creditsCost,
        generation.id,
        `${workflow.name}`
      );
      newBalance = result.newBalance;
    } catch (e) {
      await db.generation.update({
        where: { id: generation.id },
        data: { status: "FAILED", errorMsg: "Error al deducir créditos" },
      });
      return NextResponse.json({ error: "Créditos insuficientes" }, { status: 402 });
    }

    // 8. ENCOLAR EN COMFYDEPLOY
    try {
      // Agregar seed random si no viene en inputs
      if (!sanitizedInputs.seed) {
        sanitizedInputs.seed = Math.floor(Math.random() * 1_000_000_000);
      }

      const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/webhook`;
      const result = await queueComfyRun(
        workflow.deploymentId,
        sanitizedInputs,
        webhookUrl
      );

      await db.generation.update({
        where: { id: generation.id },
        data: { runId: result.run_id, status: "PROCESSING" },
      });

      return NextResponse.json({
        success: true,
        generationId: generation.id,
        runId: result.run_id,
        creditsRemaining: newBalance,
      });
    } catch (comfyError: any) {
      // REEMBOLSO INMEDIATO si ComfyDeploy falla (doc sección 2.2 Rollback)
      console.error("ComfyDeploy queue error:", comfyError.message);

      await refundCredits(userId, workflow.creditsCost, generation.id);
      await db.generation.update({
        where: { id: generation.id },
        data: { status: "FAILED", errorMsg: comfyError.message },
      });

      return NextResponse.json(
        { error: "Error al procesar. Créditos reembolsados.", refunded: workflow.creditsCost },
        { status: 500 }
      );
    }
  } catch (error: any) {
    console.error("Error en /api/generate:", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
