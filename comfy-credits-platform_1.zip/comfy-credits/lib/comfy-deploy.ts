// ============================================
// COMFYDEPLOY CLIENT - Llamadas directas a la API
// ============================================
// Basado en: Especificación de Integración ComfyDeploy API v2
// NUNCA importar este archivo en componentes del cliente.

const COMFY_API_URL = "https://api.comfydeploy.com/api/run/deployment/queue";

/**
 * Encolar una generación en ComfyDeploy.
 * Retorna el run_id para tracking.
 */
export async function queueComfyRun(
  deploymentId: string,
  inputs: Record<string, any>,
  webhookUrl: string
): Promise<{ run_id: string }> {
  const apiKey = process.env.COMFY_DEPLOY_API_KEY;
  if (!apiKey) throw new Error("COMFY_DEPLOY_API_KEY no configurada");

  const payload = {
    deployment_id: deploymentId,
    webhook: webhookUrl,
    inputs,
  };

  const response = await fetch(COMFY_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const msg = errorData.message || `HTTP ${response.status}`;
    throw new Error(`ComfyDeploy Error: ${msg}`);
  }

  const result = await response.json();
  return { run_id: result.run_id };
}

/**
 * Consultar estado de un run (para reconciliación futura).
 */
export async function getRunStatus(runId: string) {
  const apiKey = process.env.COMFY_DEPLOY_API_KEY;
  if (!apiKey) throw new Error("COMFY_DEPLOY_API_KEY no configurada");

  const response = await fetch(
    `https://api.comfydeploy.com/api/run/${runId}`,
    {
      headers: { Authorization: `Bearer ${apiKey}` },
    }
  );

  if (!response.ok) throw new Error(`Error consultando run: ${response.status}`);
  return await response.json();
}
