import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const workflows = await db.workflow.findMany({
    where: { active: true },
    orderBy: { name: "asc" },
    select: {
      id: true, name: true, description: true,
      creditsCost: true, category: true, inputSchema: true,
    },
  });
  return NextResponse.json({ workflows });
}
