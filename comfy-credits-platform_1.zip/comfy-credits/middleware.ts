import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    // Proteger rutas admin: verificar role
    if (req.nextUrl.pathname.startsWith("/admin") || req.nextUrl.pathname.startsWith("/api/admin")) {
      const token = req.nextauth.token;
      if (token?.role !== "ADMIN") {
        if (req.nextUrl.pathname.startsWith("/api/")) {
          return NextResponse.json({ error: "Acceso denegado" }, { status: 403 });
        }
        return NextResponse.redirect(new URL("/dashboard", req.url));
      }
    }
    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token,
    },
    pages: { signIn: "/login" },
  }
);

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/admin/:path*",
    "/api/generate/:path*",
    "/api/credits/:path*",
    "/api/generations/:path*",
    "/api/admin/:path*",
  ],
};
