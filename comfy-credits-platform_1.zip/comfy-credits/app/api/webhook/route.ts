// ============================================
// POST /api/webhook
// ============================================
// Receptor de webhooks de ComfyDeploy.
// Doc ref: Sección 3 - Seguridad de Webhooks
// Doc ref: Estructura de respuesta webhook (doc 1, sección 4B)

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { refundCredits } from "@/lib/credits";
import * as crypto from "crypto";

/**
 * Verificar firma HMAC del webhook (doc sección 3.1)
 */
function verifySignature(rawBody: string, signature: string | null): boolean {
  const secret = process.env.COMFY_DEPLOY_WEBHOOK_SECRET;

  // En desarrollo sin secret, permitir (solo para testing)
  if (!secret) {
    console.warn("COMFY_DEPLOY_WEBHOOK_SECRET no configurado - aceptando sin verificar");
    return process.env.NODE_ENV === "development";
  }

  if (!signature) return false;

  try {
    const computed = crypto
      .createHmac("sha256", secret)
      .update(rawBody)
      .digest("hex");

    // Comparación timing-safe
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(computed)
    );
  } catch {
    return false;
  }
}

export async function POST(req: NextRequest) {
  try {
    const rawBody = await req.text();
    const signature = req.headers.get("x-comfy-deploy-signature");

    // 1. VERIFICAR FIRMA
    if (!verifySignature(rawBody, signature)) {
      console.warn("Webhook con firma inválida rechazado");
      return NextResponse.json({ error: "Firma inválida" }, { status: 401 });
    }

    // 2. PARSEAR
    const payload = JSON.parse(rawBody);
    const { run_id, status, outputs } = payload;

    if (!run_id) {
      return NextResponse.json({ error: "run_id requerido" }, { status: 400 });
    }

    console.log(`Webhook: run_id=${run_id}, status=${status}`);

    // 3. BUSCAR GENERACIÓN
    const generation = await db.generation.findUnique({
      where: { runId: run_id },
      include: { user: { select: { id: true, email: true } } },
    });

    if (!generation) {
      console.warn(`Generación no encontrada: ${run_id}`);
      return NextResponse.json({ error: "No encontrada" }, { status: 404 });
    }

    // Idempotencia: si ya está en estado final, ignorar
    if (generation.status === "COMPLETED" || generation.status === "FAILED") {
      return NextResponse.json({ received: true, note: "already_processed" });
    }

    // 4. PROCESAR
    switch (status) {
      case "success":
      case "completed": {
        // Extraer URL de imagen (doc 1, sección 4B)
        let outputData = null;
        if (outputs && Array.isArray(outputs) && outputs.length > 0) {
          outputData = outputs;
        } else if (payload.output) {
          outputData = payload.output;
        }

        await db.generation.update({
          where: { id: generation.id },
          data: { status: "COMPLETED", outputs: outputData },
        });

        console.log(`Generación ${generation.id} completada`);
        break;
      }

      case "failed":
      case "error": {
        const errorMsg =
          payload.error?.message || payload.error_message || "Error en la generación";

        await db.generation.update({
          where: { id: generation.id },
          data: { status: "FAILED", errorMsg },
        });

        // REEMBOLSO AUTOMÁTICO (doc sección 5.1)
        await refundCredits(generation.userId, generation.creditsCost, generation.id);
        console.log(`Generación ${generation.id} falló. ${generation.creditsCost} créditos reembolsados.`);
        break;
      }

      case "processing":
      case "running": {
        await db.generation.update({
          where: { id: generation.id },
          data: { status: "PROCESSING" },
        });
        break;
      }

      case "cancelled": {
        await db.generation.update({
          where: { id: generation.id },
          data: { status: "CANCELLED" },
        });
        await refundCredits(generation.userId, generation.creditsCost, generation.id);
        break;
      }
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error("Error webhook:", error);
    return NextResponse.json({ error: "Error procesando" }, { status: 500 });
  }
}
