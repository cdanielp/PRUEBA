"use client";
import { useState, useEffect, useRef } from "react";
import { useSession } from "next-auth/react";

interface Workflow {
  id: string;
  name: string;
  description: string;
  creditsCost: number;
  category: string;
  inputSchema: { fields: any[] } | null;
}

interface ActiveGen {
  id: string;
  status: string;
  outputs: any;
  errorMsg: string | null;
  workflowName: string;
}

export default function DashboardPage() {
  const { data: session, update } = useSession();
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [selected, setSelected] = useState<Workflow | null>(null);
  const [inputs, setInputs] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [activeGens, setActiveGens] = useState<ActiveGen[]>([]);
  const pollRef = useRef<NodeJS.Timeout | null>(null);

  // Cargar workflows
  useEffect(() => {
    fetch("/api/workflows")
      .then((r) => r.json())
      .then((d) => {
        setWorkflows(d.workflows || []);
        if (d.workflows?.length === 1) setSelected(d.workflows[0]);
      });
  }, []);

  // Polling de generaciones activas
  useEffect(() => {
    async function poll() {
      if (activeGens.length === 0) return;

      const pending = activeGens.filter((g) => g.status === "QUEUED" || g.status === "PROCESSING");
      if (pending.length === 0) return;

      for (const gen of pending) {
        try {
          const res = await fetch(`/api/generations?id=${gen.id}`);
          const data = await res.json();
          if (data.generation) {
            setActiveGens((prev) =>
              prev.map((g) => (g.id === gen.id ? data.generation : g))
            );
            // Refrescar sesión para actualizar saldo si hubo reembolso
            if (data.generation.status === "FAILED") update();
          }
        } catch {}
      }
    }

    pollRef.current = setInterval(poll, 3000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [activeGens, update]);

  async function handleGenerate() {
    if (!selected) return;
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ workflowId: selected.id, inputs }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Error al generar");
        setLoading(false);
        return;
      }

      // Agregar a lista activa
      setActiveGens((prev) => [
        {
          id: data.generationId,
          status: "PROCESSING",
          outputs: null,
          errorMsg: null,
          workflowName: selected.name,
        },
        ...prev,
      ]);

      // Limpiar inputs
      setInputs({});
      // Refrescar sesión para saldo
      update();
    } catch (e: any) {
      setError("Error de conexión");
    }
    setLoading(false);
  }

  return (
    <div>
      <h1 className="text-xl font-bold mb-4">Generar</h1>

      {/* Selector de workflow (cuando haya más de 1) */}
      {workflows.length > 1 && (
        <div className="flex gap-2 mb-4">
          {workflows.map((wf) => (
            <button
              key={wf.id}
              onClick={() => { setSelected(wf); setInputs({}); }}
              className={`px-4 py-2 text-sm rounded-lg border transition ${
                selected?.id === wf.id
                  ? "border-green-500 bg-green-500/10 text-green-400"
                  : "border-neutral-800 text-neutral-400 hover:border-neutral-600"
              }`}
            >
              {wf.name} — {wf.creditsCost} créditos
            </button>
          ))}
        </div>
      )}

      {/* Formulario dinámico */}
      {selected && (
        <div className="border border-neutral-800 rounded-xl p-5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold">{selected.name}</h2>
              <p className="text-sm text-neutral-500">{selected.description}</p>
            </div>
            <span className="text-sm font-mono text-green-400">{selected.creditsCost} créditos</span>
          </div>

          {selected.inputSchema?.fields?.map((field: any) => (
            <div key={field.name} className="mb-4">
              <label className="block text-sm text-neutral-400 mb-1">
                {field.label}
                {field.required && <span className="text-red-400 ml-1">*</span>}
              </label>
              {field.type === "textarea" ? (
                <textarea
                  value={inputs[field.name] || ""}
                  onChange={(e) => setInputs({ ...inputs, [field.name]: e.target.value })}
                  placeholder={field.placeholder}
                  maxLength={field.maxLength || 1000}
                  rows={4}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-lg text-white text-sm focus:outline-none focus:border-neutral-600 resize-y"
                />
              ) : field.type === "select" ? (
                <select
                  value={inputs[field.name] || field.default || ""}
                  onChange={(e) => setInputs({ ...inputs, [field.name]: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-lg text-white text-sm focus:outline-none"
                >
                  {field.options?.map((opt: any) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              ) : (
                <input
                  type={field.type === "number" ? "number" : "text"}
                  value={inputs[field.name] || ""}
                  onChange={(e) => setInputs({ ...inputs, [field.name]: e.target.value })}
                  placeholder={field.placeholder}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-lg text-white text-sm focus:outline-none focus:border-neutral-600"
                />
              )}
            </div>
          ))}

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-sm rounded-lg p-3 mb-4">
              {error}
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full py-2.5 bg-green-600 text-white font-medium rounded-lg text-sm hover:bg-green-500 disabled:opacity-50 transition"
          >
            {loading ? "Enviando..." : `Generar (${selected.creditsCost} créditos)`}
          </button>
        </div>
      )}

      {/* Generaciones activas */}
      {activeGens.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold mb-3">Generaciones</h2>
          <div className="space-y-3">
            {activeGens.map((gen) => (
              <div
                key={gen.id}
                className="border border-neutral-800 rounded-xl p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">{gen.workflowName}</span>
                  <StatusBadge status={gen.status} />
                </div>

                {gen.status === "COMPLETED" && gen.outputs && (
                  <div className="mt-2">
                    {renderOutputs(gen.outputs)}
                  </div>
                )}

                {gen.status === "FAILED" && gen.errorMsg && (
                  <p className="text-sm text-red-400 mt-1">
                    {gen.errorMsg} — Créditos reembolsados
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    QUEUED: "bg-blue-500/10 text-blue-400",
    PROCESSING: "bg-amber-500/10 text-amber-400",
    COMPLETED: "bg-green-500/10 text-green-400",
    FAILED: "bg-red-500/10 text-red-400",
  };

  const labels: Record<string, string> = {
    QUEUED: "En cola",
    PROCESSING: "Procesando...",
    COMPLETED: "Completado",
    FAILED: "Fallido",
  };

  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${styles[status] || ""}`}>
      {status === "PROCESSING" && "⏳ "}
      {labels[status] || status}
    </span>
  );
}

function renderOutputs(outputs: any) {
  // Estructura del webhook: outputs[].data.images[].url
  try {
    if (Array.isArray(outputs)) {
      const images: string[] = [];
      for (const out of outputs) {
        if (out?.data?.images) {
          for (const img of out.data.images) {
            if (img.url) images.push(img.url);
          }
        }
      }
      if (images.length > 0) {
        return (
          <div className="grid gap-2">
            {images.map((url, i) => (
              <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                <img src={url} alt="Resultado" className="rounded-lg max-h-96 object-contain" />
              </a>
            ))}
          </div>
        );
      }
    }
    return <pre className="text-xs text-neutral-500 overflow-auto">{JSON.stringify(outputs, null, 2)}</pre>;
  } catch {
    return <p className="text-sm text-neutral-500">Output disponible</p>;
  }
}
