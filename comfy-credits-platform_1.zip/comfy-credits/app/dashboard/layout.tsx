"use client";
import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();
  const pathname = usePathname();
  const user = session?.user as any;

  const navItems = [
    { href: "/dashboard", label: "Generar" },
    { href: "/dashboard/history", label: "Historial" },
    { href: "/dashboard/credits", label: "Créditos" },
  ];

  return (
    <div className="min-h-screen">
      {/* Nav */}
      <nav className="border-b border-neutral-800 px-6 py-3 flex items-center justify-between sticky top-0 bg-neutral-950/80 backdrop-blur z-50">
        <div className="flex items-center gap-6">
          <span className="font-bold text-sm">Prompt Models Studio</span>
          <div className="flex gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`px-3 py-1.5 text-sm rounded-md transition ${
                  pathname === item.href
                    ? "bg-neutral-800 text-white"
                    : "text-neutral-500 hover:text-neutral-300"
                }`}
              >
                {item.label}
              </Link>
            ))}
            {user?.role === "ADMIN" && (
              <Link
                href="/admin"
                className={`px-3 py-1.5 text-sm rounded-md transition ${
                  pathname.startsWith("/admin")
                    ? "bg-amber-500/10 text-amber-400"
                    : "text-amber-500/60 hover:text-amber-400"
                }`}
              >
                Admin
              </Link>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-sm">
            <span className="text-neutral-500">Créditos: </span>
            <span className="font-mono font-bold text-green-400">
              {user?.creditsBalance ?? "—"}
            </span>
          </div>
          <span className="text-neutral-600 text-sm">{user?.email}</span>
          <button
            onClick={() => signOut({ callbackUrl: "/login" })}
            className="text-sm text-neutral-500 hover:text-white transition"
          >
            Salir
          </button>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto p-6">{children}</main>
    </div>
  );
}
