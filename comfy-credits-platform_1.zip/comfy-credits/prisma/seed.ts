import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Sembrando datos iniciales...\n");

  // ── Paquetes de Créditos (MXN) ──
  const packages = await Promise.all([
    prisma.creditPackage.upsert({
      where: { id: "pkg_basico" },
      update: {},
      create: {
        id: "pkg_basico",
        name: "Básico",
        credits: 50,
        priceMXN: 99,
        popular: false,
      },
    }),
    prisma.creditPackage.upsert({
      where: { id: "pkg_creator" },
      update: {},
      create: {
        id: "pkg_creator",
        name: "Creator",
        credits: 150,
        priceMXN: 249,
        popular: true,
      },
    }),
    prisma.creditPackage.upsert({
      where: { id: "pkg_pro" },
      update: {},
      create: {
        id: "pkg_pro",
        name: "Pro",
        credits: 500,
        priceMXN: 699,
        popular: false,
      },
    }),
  ]);
  console.log(`${packages.length} paquetes de créditos creados`);

  // ── Workflow inicial (Text to Image) ──
  const workflow = await prisma.workflow.upsert({
    where: { id: "wf_text_to_image" },
    update: {},
    create: {
      id: "wf_text_to_image",
      name: "Text to Image",
      description: "Genera imágenes de alta calidad a partir de texto",
      deploymentId: "REEMPLAZA_CON_TU_DEPLOYMENT_ID",
      creditsCost: 2,
      category: "image",
      inputSchema: {
        fields: [
          {
            name: "positive_prompt",
            label: "Prompt",
            type: "textarea",
            required: true,
            placeholder: "Describe la imagen que quieres generar...",
            maxLength: 1000,
          },
        ],
      },
    },
  });
  console.log(`Workflow creado: ${workflow.name}`);

  // ── Usuario Admin ──
  const adminPassword = await bcrypt.hash("admin123456", 12);
  const admin = await prisma.user.upsert({
    where: { email: "admin@promptmodels.studio" },
    update: {},
    create: {
      email: "admin@promptmodels.studio",
      name: "Admin",
      hashedPassword: adminPassword,
      role: "ADMIN",
      creditsBalance: 9999,
    },
  });
  console.log(`Admin creado: ${admin.email} (password: admin123456)`);
  console.log("\n¡Seed completado!");
  console.log("RECUERDA: Cambia el deploymentId del workflow y el password del admin");
}

main()
  .catch((e) => {
    console.error("Error en seed:", e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
