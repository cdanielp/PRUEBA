"use client";
import { useState, useEffect } from "react";

export default function CreditsPage() {
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/credits?limit=30")
      .then((r) => r.json())
      .then((d) => {
        setBalance(d.balance || 0);
        setTransactions(d.transactions || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const typeLabels: Record<string, string> = {
    PURCHASE: "Compra",
    GENERATION: "Generación",
    REFUND: "Reembolso",
    BONUS: "Bonus",
    ADMIN_ADJUST: "Ajuste Admin",
  };

  const typeStyles: Record<string, string> = {
    PURCHASE: "text-green-400",
    GENERATION: "text-red-400",
    REFUND: "text-blue-400",
    BONUS: "text-amber-400",
    ADMIN_ADJUST: "text-purple-400",
  };

  if (loading) return <p className="text-neutral-500">Cargando...</p>;

  return (
    <div>
      <h1 className="text-xl font-bold mb-4">Créditos</h1>

      <div className="border border-neutral-800 rounded-xl p-5 mb-6">
        <p className="text-sm text-neutral-500 mb-1">Saldo actual</p>
        <p className="text-4xl font-mono font-bold text-green-400">{balance}</p>
        <p className="text-sm text-neutral-600 mt-1">créditos disponibles</p>
      </div>

      <h2 className="text-lg font-semibold mb-3">Movimientos</h2>

      {transactions.length === 0 ? (
        <p className="text-neutral-500 text-sm">Sin movimientos.</p>
      ) : (
        <div className="space-y-1">
          {transactions.map((tx) => (
            <div
              key={tx.id}
              className="flex items-center justify-between border border-neutral-800/50 rounded-lg p-3"
            >
              <div>
                <span className={`text-xs font-medium ${typeStyles[tx.type] || "text-neutral-400"}`}>
                  {typeLabels[tx.type] || tx.type}
                </span>
                {tx.description && (
                  <p className="text-xs text-neutral-600 mt-0.5">{tx.description}</p>
                )}
              </div>
              <div className="text-right">
                <span className={`font-mono text-sm font-bold ${tx.amount > 0 ? "text-green-400" : "text-red-400"}`}>
                  {tx.amount > 0 ? "+" : ""}{tx.amount}
                </span>
                <p className="text-xs text-neutral-600">
                  Saldo: {tx.balanceAfter}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
