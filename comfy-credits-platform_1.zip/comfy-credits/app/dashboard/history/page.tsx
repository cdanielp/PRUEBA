"use client";
import { useState, useEffect } from "react";

export default function HistoryPage() {
  const [generations, setGenerations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/generations?limit=50")
      .then((r) => r.json())
      .then((d) => { setGenerations(d.generations || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-neutral-500">Cargando...</p>;

  return (
    <div>
      <h1 className="text-xl font-bold mb-4">Historial de Generaciones</h1>

      {generations.length === 0 ? (
        <p className="text-neutral-500 text-sm">No tienes generaciones todavía.</p>
      ) : (
        <div className="space-y-2">
          {generations.map((gen) => (
            <div
              key={gen.id}
              className="flex items-center justify-between border border-neutral-800 rounded-lg p-4"
            >
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium">{gen.workflowName}</span>
                <StatusBadge status={gen.status} />
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="font-mono text-neutral-400">{gen.creditsCost} cr</span>
                <span className="text-neutral-600">
                  {new Date(gen.createdAt).toLocaleString("es-MX", {
                    day: "numeric", month: "short", hour: "2-digit", minute: "2-digit",
                  })}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    QUEUED: "bg-blue-500/10 text-blue-400",
    PROCESSING: "bg-amber-500/10 text-amber-400",
    COMPLETED: "bg-green-500/10 text-green-400",
    FAILED: "bg-red-500/10 text-red-400",
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${styles[status] || ""}`}>
      {status}
    </span>
  );
}
