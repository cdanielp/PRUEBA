// ============================================
// POST /api/stripe-webhook
// ============================================
// Recibe confirmación de pago de Stripe
// y acredita los créditos al usuario.

import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { addPurchasedCredits } from "@/lib/credits";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-11-20.acacia" as any,
});

export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json(
      { error: "Sin firma de Stripe" },
      { status: 400 }
    );
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err: any) {
    console.error("Error verificando firma de Stripe:", err.message);
    return NextResponse.json(
      { error: "Firma inválida" },
      { status: 400 }
    );
  }

  // Procesar el evento
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const { userId, credits, packageId } = session.metadata || {};

    if (!userId || !credits) {
      console.error("Metadata incompleta en checkout session");
      return NextResponse.json(
        { error: "Metadata incompleta" },
        { status: 400 }
      );
    }

    try {
      await addPurchasedCredits(
        userId,
        parseInt(credits),
        session.id,
        `Compra de ${credits} créditos (Paquete: ${packageId})`
      );

      console.log(
        `💰 ${credits} créditos acreditados al usuario ${userId}`
      );
    } catch (error) {
      console.error("Error acreditando créditos:", error);
      // Stripe reintentará el webhook
      return NextResponse.json(
        { error: "Error procesando pago" },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({ received: true });
}

// Desactivar el body parser de Next.js para que Stripe pueda verificar la firma
export const config = {
  api: { bodyParser: false },
};
